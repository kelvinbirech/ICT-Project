# ICT-Project

THIS REPO IS FOR THE LAST PROJECT OF COURSE WORK DSE. Collaborated by 4 members Omar moh'dNoor (Spokesperson), Kiplangat Edwin(Process Analyst), Humprey Kamau Njeri(Quality Control) and Kelvin Birech(Team Leader) towards DEVELOPMENT OF AN ONLINE ICT ACCES SYSTEM BASED ON KENYA

  - [Introductuion](#introduction)
  - [Objectives](#objectives)
  - [Software Requirement Specification](#software-requirement-specification)
  - [The Users Of The System](#the-users-of-the-system)
  - [Functional Requirements](#functional-requirements)
  - [Authentication Module](#Authentication-Module)
  - [Software Design Description](#software-design-description)

## Introductuion
This is a group project aimed towards the development of an online ICT service access system for easy access of ICT services from ICT proffesionals.
This system will quench the high demand of ICT services by connecting employers with their employees of choice.
## Objectives
The objectives of this project is to allow the new employees seeking or quenching their unemployment thirst to their respective employers.

## The Users Of The System
   1.Employees

   2.Employers

## Functional Requirements.
     1. Creating User Accounts
        a)ask the user to either sign in or sign up.
        b) if sign up,a window that asks individuals credentials will appear.
             
     2. Login
       a) provides the user with text fields where they are asked to enter their username or password.
       b) if the username and the password is correct,the user will be directed to the homepage or dashboard of the system.
       C) if the password or the username is incorrect,the user will be asked to enter correct credentials. 

     3. Profile
     4. logout
     5. Password Reset
     6. Profile Editing

## Software Design Description

It contains images of how the system look
